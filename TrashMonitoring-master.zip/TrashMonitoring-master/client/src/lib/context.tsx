import React from "react";

const AppContext = React.createContext<any>({});
const PageContext = React.createContext<any>({});

export { AppContext, PageContext};